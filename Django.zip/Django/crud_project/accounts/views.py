from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from .forms import SignupForm, LoginForm
from django.contrib.auth import get_user_model
from django.contrib import messages


# Signup view
def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            # Ensure the username is unique before creating the user
            username = form.cleaned_data['username']
            if get_user_model().objects.filter(username=username).exists():
                form.add_error('username', 'This username is already taken.')
            else:
                user = form.save(commit=False)
                user.set_password(form.cleaned_data['password'])
                user.save()
                login(request, user)  # Log in the user after successful signup
                return redirect('index')  # Redirect to home page
    else:
        form = SignupForm()
    return render(request, 'accounts/signup.html', {'form': form})


# Login view
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request=request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)  # Log in the user
            return redirect('index')  # Redirect to home page
        else:
            form.add_error(None, "Invalid credentials, please try again.")
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})


# Logout view
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")  # Optional success message
    return redirect('login')  # Redirect to the login page after logging out
