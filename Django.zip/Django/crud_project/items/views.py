from django.shortcuts import render, get_object_or_404, redirect
from .models import Item
from .forms import ItemForm
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator


# Display items for the logged-in user with search functionality
@login_required
def index(request):
    query = request.GET.get('search', '')  # Get the search term from the URL parameters
    items = Item.objects.filter(user=request.user)  # Filter items by the logged-in user

    if query:
        # If a search query exists, filter items by name or description
        items = items.filter(
            name__icontains=query
        ) | items.filter(description__icontains=query)

    paginator = Paginator(items, 10)  # Show 10 items per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'items/index.html', {'page_obj': page_obj, 'query': query})





@login_required
def create_item(request):
    if request.method == 'POST':
        form = ItemForm(request.POST)
        if form.is_valid():
            item = form.save(commit=False)
            item.user = request.user  # Associate the item with the logged-in user
            item.save()
            return redirect('index')  # Redirect to the index page after saving
    else:
        form = ItemForm()

    return render(request, 'items/create_item.html', {'form': form})

# Update item
@login_required
def update_item(request, id):
    item = get_object_or_404(Item, id=id, user=request.user)
    if request.method == 'POST':
        form = ItemForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = ItemForm(instance=item)

    return render(request, 'items/update_item.html', {'form': form, 'item': item})

# Delete item
@login_required
def delete_item(request, id):
    item = get_object_or_404(Item, id=id, user=request.user)  # Ensure the item belongs to the user
    if request.method == 'POST':
        item.delete()
        return redirect('index')
    return render(request, 'items/delete_item.html', {'item': item})
